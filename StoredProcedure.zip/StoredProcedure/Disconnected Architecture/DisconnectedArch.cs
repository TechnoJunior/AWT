﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace Disconnected_Architecture
{
    public partial class F2 : Form
    {
        SqlConnection cn;
        SqlDataAdapter da;
        DataSet ds=new DataSet();
        DataRow dr;
        SqlCommandBuilder cb;
        int CountId,EmpId=0;
        public F2()
        {
            InitializeComponent();
        }
        private int count()
        {
            CountId = ds.Tables["Movie"].Rows.Count;
            return CountId;
        }
        private void F2_Load(object sender, EventArgs e)
        {
            cb1.Text = "Select an Number";
            clear();
            t2.Enabled = false;
            t3.Enabled = false;
            t4.Enabled = false;
            Add.Enabled = false;
            Edit.Enabled = false;
            Update.Enabled = false;
            
            cn = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=C:\\Users\\Mani\\Documents\\Visual Studio 2012\\Projects\\StoredProcedure\\StoredProcedure\\HP.mdf;Integrated Security=True");
            string query = "select * from emp";
            da = new SqlDataAdapter(query,cn);
            da.Fill(ds,"Movie");

            //count = ds.Tables["Movie"].Rows.Count;
            for (int i = 0; i <= count(); i++)
            { 
                cb1.Items.Add(ds.Tables["Movie"].Rows[i][0].ToString());
                cb1.DisplayMember = ds.Tables["Movie"].Rows[i][0].ToString();
                cb1.ValueMember = ds.Tables["Movie"].Rows[i][0].ToString();
            }
        }
        private void clear()
        {
            ladd.Text = "";
            ldelete.Text = "";
            lname.Text = "";
            lchar.Text = "";
            lsal.Text = "";
            lupdate.Text = "";
            ldelete.Text = "";
        }

        private void Display()
        {
            cb1.Text = ds.Tables["Movie"].Rows[EmpId][0].ToString();
            t2.Text = ds.Tables["Movie"].Rows[EmpId][1].ToString();
            t3.Text = ds.Tables["Movie"].Rows[EmpId][2].ToString();
            t4.Text = ds.Tables["Movie"].Rows[EmpId][3].ToString();
        }
        private void cb1_SelectedIndexChanged(object sender, EventArgs e)
        {
            t2.Enabled = false;
            t3.Enabled = false;
            t4.Enabled = false;
            Edit.Enabled = true;
            Add.Enabled = false;
            Update.Enabled = false;
            EmpId = int.Parse(cb1.SelectedItem.ToString())-1; 
            Display();
            clear();
        }

        private void First_Click(object sender, EventArgs e)
        {
            EmpId = 0;
            Display();
        }

        private void Last_Click(object sender, EventArgs e)
        {
            EmpId = count() - 1;
            Display();
        }

        private void Previous_Click(object sender, EventArgs e)
        {
            if (EmpId == 0)
            {
                EmpId = 0;
            }
            else
            {
                EmpId--;
            }
            Display();
        }

        private void Next_Click(object sender, EventArgs e)
        {
            if (EmpId < count() - 1)
            {
                EmpId++;
                Display();
                clear();
            }
        }

        private void New_Click(object sender, EventArgs e)
        {
            int a = count()+1;
            cb1.Text = a.ToString();
            t2.Enabled = true;
            t3.Enabled = true;
            t4.Enabled = true;
            t2.Text = "";
            t3.Text = "";
            t4.Text = "";
            Add.Enabled = true;
            Edit.Enabled = true;
            Update.Enabled = false;
        }

        private void Add_Click(object sender, EventArgs e)
        {
            dr = ds.Tables["Movie"].NewRow();
            dr["Id"] = count() + 1;
            dr["name"] = t2.Text;
            dr["desg"] = t3.Text;
            dr["salary"] = t4.Text;
            ds.Tables["Movie"].Rows.Add(dr);

            ladd.Text = "Record Inserted!!!!";
            t2.Text = "";
            t3.Text = "";
            t4.Text = "";
            Add.Enabled = false;
            Edit.Enabled = true;
            Update.Enabled = false;
        }

        private void Edit_Click(object sender, EventArgs e)
        {
            t2.Enabled = true;
            t3.Enabled = true;
            t4.Enabled = true;
            Add.Enabled = false;
            Update.Enabled = true;
            Edit.Enabled = false;
        }

        private void Update_Click(object sender, EventArgs e)
        {
            EmpId = int.Parse(cb1.SelectedItem.ToString()) - 1;
            dr = ds.Tables["Movie"].Rows[EmpId];
            dr["name"]=t2.Text;
            dr["desg"] = t3.Text;
            dr["salary"] = t4.Text;
            lupdate.Text = "Updated";
            Display();
            Update.Enabled = false;
            Add.Enabled = false;
            Edit.Enabled = true;
        }

        private void UpdateDb_Click(object sender, EventArgs e)
        {
            cb = new SqlCommandBuilder(da);
            da = cb.DataAdapter;
            da.Update(ds, "Movie");

            MessageBox.Show("Database Updated!!!!!");
        }

    }
}

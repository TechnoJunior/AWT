﻿namespace Disconnected_Architecture
{
    partial class F2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ldelete = new System.Windows.Forms.Label();
            this.lupdate = new System.Windows.Forms.Label();
            this.lsal = new System.Windows.Forms.Label();
            this.lchar = new System.Windows.Forms.Label();
            this.lname = new System.Windows.Forms.Label();
            this.ladd = new System.Windows.Forms.Label();
            this.cb1 = new System.Windows.Forms.ComboBox();
            this.Last = new System.Windows.Forms.Button();
            this.Next = new System.Windows.Forms.Button();
            this.Previous = new System.Windows.Forms.Button();
            this.First = new System.Windows.Forms.Button();
            this.Update = new System.Windows.Forms.Button();
            this.Edit = new System.Windows.Forms.Button();
            this.Add = new System.Windows.Forms.Button();
            this.New = new System.Windows.Forms.Button();
            this.t4 = new System.Windows.Forms.TextBox();
            this.t3 = new System.Windows.Forms.TextBox();
            this.t2 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.l1 = new System.Windows.Forms.Label();
            this.UpdateDb = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // ldelete
            // 
            this.ldelete.AutoSize = true;
            this.ldelete.Location = new System.Drawing.Point(261, 205);
            this.ldelete.Name = "ldelete";
            this.ldelete.Size = new System.Drawing.Size(44, 13);
            this.ldelete.TabIndex = 65;
            this.ldelete.Text = "Deleted";
            // 
            // lupdate
            // 
            this.lupdate.AutoSize = true;
            this.lupdate.Location = new System.Drawing.Point(207, 205);
            this.lupdate.Name = "lupdate";
            this.lupdate.Size = new System.Drawing.Size(48, 13);
            this.lupdate.TabIndex = 63;
            this.lupdate.Text = "Updated";
            // 
            // lsal
            // 
            this.lsal.AutoSize = true;
            this.lsal.Location = new System.Drawing.Point(376, 179);
            this.lsal.Name = "lsal";
            this.lsal.Size = new System.Drawing.Size(64, 13);
            this.lsal.TabIndex = 62;
            this.lsal.Text = "Enter Salary";
            // 
            // lchar
            // 
            this.lchar.AutoSize = true;
            this.lchar.Location = new System.Drawing.Point(376, 144);
            this.lchar.Name = "lchar";
            this.lchar.Size = new System.Drawing.Size(57, 13);
            this.lchar.TabIndex = 61;
            this.lchar.Text = "Enter Char";
            // 
            // lname
            // 
            this.lname.AutoSize = true;
            this.lname.Location = new System.Drawing.Point(376, 108);
            this.lname.Name = "lname";
            this.lname.Size = new System.Drawing.Size(63, 13);
            this.lname.TabIndex = 60;
            this.lname.Text = "Enter Name";
            // 
            // ladd
            // 
            this.ladd.AutoSize = true;
            this.ladd.Location = new System.Drawing.Point(161, 206);
            this.ladd.Name = "ladd";
            this.ladd.Size = new System.Drawing.Size(45, 13);
            this.ladd.TabIndex = 59;
            this.ladd.Text = "Inserted";
            // 
            // cb1
            // 
            this.cb1.FormattingEnabled = true;
            this.cb1.Location = new System.Drawing.Point(122, 68);
            this.cb1.Name = "cb1";
            this.cb1.Size = new System.Drawing.Size(121, 21);
            this.cb1.TabIndex = 58;
            this.cb1.SelectedIndexChanged += new System.EventHandler(this.cb1_SelectedIndexChanged);
            // 
            // Last
            // 
            this.Last.Font = new System.Drawing.Font("Monotype Corsiva", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Last.Location = new System.Drawing.Point(278, 174);
            this.Last.Name = "Last";
            this.Last.Size = new System.Drawing.Size(75, 23);
            this.Last.TabIndex = 57;
            this.Last.Text = ">>";
            this.Last.UseVisualStyleBackColor = true;
            this.Last.Click += new System.EventHandler(this.Last_Click);
            // 
            // Next
            // 
            this.Next.Font = new System.Drawing.Font("Monotype Corsiva", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Next.Location = new System.Drawing.Point(278, 139);
            this.Next.Name = "Next";
            this.Next.Size = new System.Drawing.Size(75, 23);
            this.Next.TabIndex = 56;
            this.Next.Text = ">";
            this.Next.UseVisualStyleBackColor = true;
            this.Next.Click += new System.EventHandler(this.Next_Click);
            // 
            // Previous
            // 
            this.Previous.Font = new System.Drawing.Font("Monotype Corsiva", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Previous.Location = new System.Drawing.Point(278, 103);
            this.Previous.Name = "Previous";
            this.Previous.Size = new System.Drawing.Size(75, 23);
            this.Previous.TabIndex = 55;
            this.Previous.Text = "<";
            this.Previous.UseVisualStyleBackColor = true;
            this.Previous.Click += new System.EventHandler(this.Previous_Click);
            // 
            // First
            // 
            this.First.Font = new System.Drawing.Font("Monotype Corsiva", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.First.Location = new System.Drawing.Point(278, 68);
            this.First.Name = "First";
            this.First.Size = new System.Drawing.Size(75, 23);
            this.First.TabIndex = 54;
            this.First.Text = "<<";
            this.First.UseVisualStyleBackColor = true;
            this.First.Click += new System.EventHandler(this.First_Click);
            // 
            // Update
            // 
            this.Update.Font = new System.Drawing.Font("Monotype Corsiva", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Update.Location = new System.Drawing.Point(278, 229);
            this.Update.Name = "Update";
            this.Update.Size = new System.Drawing.Size(75, 23);
            this.Update.TabIndex = 53;
            this.Update.Text = "Update";
            this.Update.UseVisualStyleBackColor = true;
            this.Update.Click += new System.EventHandler(this.Update_Click);
            // 
            // Edit
            // 
            this.Edit.Font = new System.Drawing.Font("Monotype Corsiva", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Edit.Location = new System.Drawing.Point(197, 229);
            this.Edit.Name = "Edit";
            this.Edit.Size = new System.Drawing.Size(75, 23);
            this.Edit.TabIndex = 52;
            this.Edit.Text = "Edit";
            this.Edit.UseVisualStyleBackColor = true;
            this.Edit.Click += new System.EventHandler(this.Edit_Click);
            // 
            // Add
            // 
            this.Add.Font = new System.Drawing.Font("Monotype Corsiva", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Add.Location = new System.Drawing.Point(116, 229);
            this.Add.Name = "Add";
            this.Add.Size = new System.Drawing.Size(75, 23);
            this.Add.TabIndex = 51;
            this.Add.Text = "Add";
            this.Add.UseVisualStyleBackColor = true;
            this.Add.Click += new System.EventHandler(this.Add_Click);
            // 
            // New
            // 
            this.New.Font = new System.Drawing.Font("Monotype Corsiva", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.New.Location = new System.Drawing.Point(35, 229);
            this.New.Name = "New";
            this.New.Size = new System.Drawing.Size(75, 23);
            this.New.TabIndex = 50;
            this.New.Text = "New";
            this.New.UseVisualStyleBackColor = true;
            this.New.Click += new System.EventHandler(this.New_Click);
            // 
            // t4
            // 
            this.t4.Location = new System.Drawing.Point(122, 179);
            this.t4.Name = "t4";
            this.t4.Size = new System.Drawing.Size(124, 20);
            this.t4.TabIndex = 49;
            // 
            // t3
            // 
            this.t3.Location = new System.Drawing.Point(122, 144);
            this.t3.Name = "t3";
            this.t3.Size = new System.Drawing.Size(124, 20);
            this.t3.TabIndex = 48;
            // 
            // t2
            // 
            this.t2.Location = new System.Drawing.Point(122, 108);
            this.t2.Name = "t2";
            this.t2.Size = new System.Drawing.Size(124, 20);
            this.t2.TabIndex = 47;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Monotype Corsiva", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(67, 179);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 18);
            this.label5.TabIndex = 46;
            this.label5.Text = "Salary";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Monotype Corsiva", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(64, 144);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(34, 18);
            this.label4.TabIndex = 45;
            this.label4.Text = "Char";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Monotype Corsiva", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(64, 108);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 18);
            this.label3.TabIndex = 44;
            this.label3.Text = "Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Monotype Corsiva", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(67, 74);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(22, 18);
            this.label2.TabIndex = 43;
            this.label2.Text = "Id";
            // 
            // l1
            // 
            this.l1.AutoSize = true;
            this.l1.Font = new System.Drawing.Font("Monotype Corsiva", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l1.Location = new System.Drawing.Point(62, 26);
            this.l1.Name = "l1";
            this.l1.Size = new System.Drawing.Size(244, 25);
            this.l1.TabIndex = 42;
            this.l1.Text = "Welcome to Wizarding World!!";
            this.l1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // UpdateDb
            // 
            this.UpdateDb.Font = new System.Drawing.Font("Monotype Corsiva", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UpdateDb.Location = new System.Drawing.Point(149, 258);
            this.UpdateDb.Name = "UpdateDb";
            this.UpdateDb.Size = new System.Drawing.Size(123, 23);
            this.UpdateDb.TabIndex = 66;
            this.UpdateDb.Text = "Update Databasae";
            this.UpdateDb.UseVisualStyleBackColor = true;
            this.UpdateDb.Click += new System.EventHandler(this.UpdateDb_Click);
            // 
            // F2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(473, 286);
            this.Controls.Add(this.UpdateDb);
            this.Controls.Add(this.ldelete);
            this.Controls.Add(this.lupdate);
            this.Controls.Add(this.lsal);
            this.Controls.Add(this.lchar);
            this.Controls.Add(this.lname);
            this.Controls.Add(this.ladd);
            this.Controls.Add(this.cb1);
            this.Controls.Add(this.Last);
            this.Controls.Add(this.Next);
            this.Controls.Add(this.Previous);
            this.Controls.Add(this.First);
            this.Controls.Add(this.Update);
            this.Controls.Add(this.Edit);
            this.Controls.Add(this.Add);
            this.Controls.Add(this.New);
            this.Controls.Add(this.t4);
            this.Controls.Add(this.t3);
            this.Controls.Add(this.t2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.l1);
            this.Name = "F2";
            this.Text = "Disconnected Architecture";
            this.Load += new System.EventHandler(this.F2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label ldelete;
        private System.Windows.Forms.Label lupdate;
        private System.Windows.Forms.Label lsal;
        private System.Windows.Forms.Label lchar;
        private System.Windows.Forms.Label lname;
        private System.Windows.Forms.Label ladd;
        private System.Windows.Forms.ComboBox cb1;
        private System.Windows.Forms.Button Last;
        private System.Windows.Forms.Button Next;
        private System.Windows.Forms.Button Previous;
        private System.Windows.Forms.Button First;
        private System.Windows.Forms.Button Update;
        private System.Windows.Forms.Button Edit;
        private System.Windows.Forms.Button Add;
        private System.Windows.Forms.Button New;
        private System.Windows.Forms.TextBox t4;
        private System.Windows.Forms.TextBox t3;
        private System.Windows.Forms.TextBox t2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label l1;
        private System.Windows.Forms.Button UpdateDb;

    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace StoredProcedure
{
    public partial class StoredProcedure : Form
    {
        SqlConnection cn;
        SqlCommand cm;
        SqlDataReader dr;
        SqlDataAdapter da;
        DataSet ds = new DataSet();
        SqlCommandBuilder cb;
        int EmpId;

        public StoredProcedure()
        {
            InitializeComponent();
        }
        private void clear()
        {
            ladd.Text = "";
            ldelete.Text = "";
            lname.Text = "";
            lchar.Text = "";
            lsal.Text = "";
            lupdate.Text = "";
            ldelete.Text = "";
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            cb1.Text = "Select an Number";
            clear();
            t2.Enabled = false;
            t3.Enabled = false;
            t4.Enabled = false;
            Add.Enabled = false;
            Edit.Enabled = false;
            Update.Enabled = false;
            Delete.Enabled = false;
            cn = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=C:\\Users\\Mani\\Documents\\Visual Studio 2012\\Projects\\StoredProcedure\\StoredProcedure\\HP.mdf;Integrated Security=True");
            cn.Open();
            string query = "select Id from emp";
            cm = new SqlCommand(query, cn);
            dr = cm.ExecuteReader();
            while (dr.Read())
            {
                cb1.Items.Add(dr["Id"].ToString());
            }
            cn.Close();            
        }
        private void display(int eid)
        {
            cb1.Text = eid.ToString();
            cb1.Enabled = true;
            t2.Enabled = false;
            t3.Enabled = false;
            t4.Enabled = false;
            Add.Enabled = false;

            Update.Enabled = false;
            cn.Open();
            cm = new SqlCommand("select * from emp where Id=" + eid, cn);
            dr = cm.ExecuteReader();
            while (dr.Read())
            {
                t2.Text = dr["name"].ToString();
                t3.Text = dr["desg"].ToString();
                t4.Text = dr["salary"].ToString();
            }
            cn.Close();
        }
        private void cb1_SelectedIndexChanged(object sender, EventArgs e)
        {
            t2.Enabled = false;
            t3.Enabled = false;
            t4.Enabled = false;
            Edit.Enabled = true;
            Delete.Enabled = true;
            Add.Enabled = false;
            Update.Enabled = false;
            display(int.Parse(cb1.SelectedItem.ToString()));
            clear();
        }

        private void First_Click(object sender, EventArgs e)
        {
            display(1);
            clear();
        }

        private void Previous_Click(object sender, EventArgs e)
        {
            if (EmpId == 0)
            {
                EmpId = 1;
            }
            else
            {
                EmpId--;
            }
            display(EmpId);
            clear();
        }

        private void Next_Click(object sender, EventArgs e)
        {

        }

        private void Edit_Click(object sender, EventArgs e)
        {
            t2.Enabled = true;
            t3.Enabled = true;
            t4.Enabled = true;
            Add.Enabled = false;
            Update.Enabled = true;
            Edit.Enabled = false;
            Delete.Enabled = false;
        }

        private void Update_Click(object sender, EventArgs e)
        {
            cn.Open();
            cm = new SqlCommand("update emp set name=@nm,desg=@des,salary=@sal where Id=@EmpId", cn);
            cm.Parameters.AddWithValue("nm", t2.Text);
            cm.Parameters.AddWithValue("des", t3.Text);
            cm.Parameters.AddWithValue("sal", t4.Text);
            cm.Parameters.AddWithValue("EmpId", EmpId);
            int result1 = cm.ExecuteNonQuery();
            cn.Close();
            if (result1 > 0)
            {
                lupdate.Text = "Updated";
                display(EmpId);
                Update.Enabled = false;
                Add.Enabled = false;
                Delete.Enabled = true;
                Edit.Enabled = true;
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ConnectedArchitecture
{
    public partial class F1 : Form
    {
        SqlConnection cn;
        SqlCommand cm;
        SqlDataReader dr;
        int EmpId=1,id;

        public F1()
        {
            InitializeComponent();
        }

        private void F1_Load(object sender, EventArgs e)
        {
            cb1.Text = "Select an Number";
            clear();
            t2.Enabled = false;
            t3.Enabled = false;
            t4.Enabled = false;
            Add.Enabled = false;
            Edit.Enabled = false;
            Update.Enabled = false;
            Delete.Enabled = false;
            cn = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=C:\\Users\\Mani\\Documents\\Visual Studio 2012\\Projects\\StoredProcedure\\StoredProcedure\\HP.mdf;Integrated Security=True");
            cn.Open();
            string query = "select Id from emp";
            cm = new SqlCommand(query, cn);
            dr = cm.ExecuteReader();
            while (dr.Read())
            {
                cb1.Items.Add(dr["Id"].ToString());
            }
            cn.Close();
        }
        private int count()
        {
            cn.Open();
                string query = "select count(id) from emp";
                cm = new SqlCommand(query, cn);
                id = (int)cm.ExecuteScalar();
                id = id + 1;
                cn.Close();
                return id;
            
        }
        private void New_Click(object sender, EventArgs e)
        {
            t2.Enabled = true;
            t3.Enabled = true;
            t4.Enabled = true;
            Edit.Enabled = false;
            Delete.Enabled = false;
            Update.Enabled = false;
            Add.Enabled = true;
            t2.Text = "";
            t3.Text = "";
            t4.Text = "";
            id = count();
            cb1.Text = id.ToString();
        }

        private void Add_Click(object sender, EventArgs e)
        {
            ladd.Text = "";
            lname.Text = "";
            lchar.Text = "";
            lsal.Text = "";
            int i = 4;
            id = count();
            /*if(string.IsNullOrEmpty(t2.Text))
            {
                lname.Text="Enter Name";
                i++;
            }
            if(string.IsNullOrEmpty(t3.Text))
            {
                lchar.Text="Enter Character";
                i++;
            }
            if(string.IsNullOrEmpty(t4.Text))
            {
                lsal.Text="Enter Salary";
                i++;
            }*/
            cn.Open();
            if (i >= 3)
            {
                string query = "insert into emp values(@Id,@name,@desg,@salary)";
                cm = new SqlCommand(query, cn);
                cm.Parameters.AddWithValue("Id", id);
                cm.Parameters.AddWithValue("name", t2.Text);
                cm.Parameters.AddWithValue("desg", t3.Text);
                cm.Parameters.AddWithValue("salary", t4.Text);           
                int result = cm.ExecuteNonQuery();
                if (result > 0)
                {
                    ladd.Text = "Record Inserted!!!!";
                    t2.Text = "";
                    t3.Text = "";
                    t4.Text = "";
                    Add.Enabled = false;
                    Edit.Enabled = true;
                    Delete.Enabled = true;
                    Update.Enabled = false;
                }
            }
            cn.Close();
            EmpId = id;
            display();
        }

        private void cb1_SelectedIndexChanged(object sender, EventArgs e)
        {
            t2.Enabled = false;
            t3.Enabled = false;
            t4.Enabled = false;
            Edit.Enabled = true;
            Delete.Enabled = true;
            Add.Enabled = false;
            Update.Enabled = false;
            cn.Open();
            cm = new SqlCommand("select * from emp where Id="+cb1.SelectedItem,cn);
            dr = cm.ExecuteReader();
            while (dr.Read())
            {
                EmpId = (int)dr["Id"];
                t2.Text=dr["name"].ToString();
                t3.Text = dr["desg"].ToString();
                t4.Text = dr["salary"].ToString();
            }
            cn.Close();
            clear();
        }

        private void First_Click(object sender, EventArgs e)
        {
            EmpId = 1;
            display();
            clear();
        }
        private void display()
        {
            cb1.Text = EmpId.ToString();
            cb1.Enabled = true;
            t2.Enabled = false;
            t3.Enabled = false;
            t4.Enabled = false;
            Add.Enabled = false;
            
            Update.Enabled = false;
            cn.Open();
            cm = new SqlCommand("select * from emp where Id="+EmpId,cn);
            dr = cm.ExecuteReader();
            while(dr.Read())
            {
                t2.Text=dr["name"].ToString();
                t3.Text = dr["desg"].ToString();
                t4.Text = dr["salary"].ToString();
            }
            cn.Close();
        }
        private void clear()
        {
            ladd.Text = "";
            ldelete.Text = "";
            lname.Text = "";
            lchar.Text = "";
            lsal.Text = "";
            lupdate.Text = "";
            ldelete.Text = "";
        }
        private void Previous_Click(object sender, EventArgs e)
        {
            if (EmpId == 1)
            {
                EmpId = 1;
            }
            else
            {
                EmpId--;
            }
            display();
            clear();
        }

        private void Next_Click(object sender, EventArgs e)
        {
            if(EmpId<count()-1)
            {
                EmpId++;
                display();
                clear();
            }
        }

        private void Last_Click(object sender, EventArgs e)
        {
            EmpId = count()-1;
            display();
            clear();
        }

        private void Update_Click(object sender, EventArgs e)
        {
            cn.Open();
            cm = new SqlCommand("update emp set name=@nm,desg=@des,salary=@sal where Id=@EmpId",cn);
            cm.Parameters.AddWithValue("nm",t2.Text);
            cm.Parameters.AddWithValue("des", t3.Text);
            cm.Parameters.AddWithValue("sal", t4.Text);
            cm.Parameters.AddWithValue("EmpId", EmpId);
            int result1=cm.ExecuteNonQuery();
            cn.Close();
            if (result1 > 0)
            {
                lupdate.Text = "Updated";
                display();
                Update.Enabled = false;
                Add.Enabled = false;
                Delete.Enabled = true;
                Edit.Enabled = true;
            }
        }

        private void Edit_Click(object sender, EventArgs e)
        {
            t2.Enabled = true;
            t3.Enabled = true;
            t4.Enabled = true;
            Add.Enabled = false;
            Update.Enabled = true;
            Edit.Enabled = false;
            Delete.Enabled = false;
        }

        private void Delete_Click(object sender, EventArgs e)
        {
            cn.Open();
            cm = new SqlCommand("delete from emp where Id=@EmpId",cn);
            cm.Parameters.AddWithValue("EmpId", EmpId);
            int delete=cm.ExecuteNonQuery();
            cn.Close();
            if (delete > 0)
            {
                ldelete.Text = "Record Deleted";
                if (EmpId == 1)
                {
                    display();
                }
                else
                {
                    EmpId--;
                    display();
                }
            }
        }
    }
}